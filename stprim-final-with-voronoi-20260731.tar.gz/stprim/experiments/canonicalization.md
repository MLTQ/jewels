# canonicalization.py

## Purpose
The go/no-go experiment. Stage 2 requires that fitted primitive sets be canonical — same clip,
different seeds, comparable configurations. If they aren't, there is no learnable distribution
over primitive sets and no model capacity fixes it.

## Components

### `chamfer(a, b)`
- **Does**: symmetric mean nearest-neighbour distance between center sets

### `marginals(field)`
- **Does**: scale median/IQR, anisotropy median, weight median
- **Rationale**: even when individual primitives don't correspond, matching *distributions* are
  enough for a permutation-invariant (set-diffusion) prior. Distinguishes "weakly canonical"
  from "hopeless".

### `main()`
- **Does**: two seeded fits, reports Chamfer + a random-cloud baseline + marginals

## Decisions
- Random-cloud baseline included because raw Chamfer is uninterpretable without a scale. The
  **ratio** is the number to read.
- Expects Voronoi to score better than additive: given seeds the tessellation is deterministic,
  and Lloyd relaxation toward a centroidal tessellation is an actual canonicalization procedure,
  which unnormalized splats do not have.

## Contracts

| Dependent | Expects | Breaking changes |
|-----------|---------|------------------|
| decision to build stage 2 | ratio << 1, or ratio ~1 with matching marginals | — |

## Notes
- Harness verified at toy budget only (ratio 0.836 on a 20px/60-step run). **That number is
  meaningless** — undertrained fits haven't converged anywhere. Run at real budget on GPU.
- Real-budget results (2026-07-31, see PROJECT.md): additive beat voronoi on both synthetic
  (0.749 vs 0.825) and real footage (0.621 vs 0.745), contradicting the expectation above —
  but vanilla voronoi never had its claimed mechanism running.
- `--steelman` (voronoi only) enables that mechanism: background pseudo-cell + interleaved
  Lloyd + a full-strength Lloyd polish (`fit/lloyd.md`). This is the keep-or-kill run.
- `--bg-cell` (voronoi only) is the ablation: pseudo-cell without Lloyd, to attribute effects
  to the right mechanism.
