# render.py

## Purpose
Evaluates a primitive field at arbitrary query points. Holds the central design claim: additive
splats and soft anisotropic Voronoi are the same model under different normalization of the
per-primitive contribution.

## Components

### `cull_knn(points, mu, k)`
- **Does**: k nearest primitives per query point by Euclidean center distance -> (M,k)
- **Rationale**: Euclidean, not Mahalanobis, on purpose. Culling needs a safe superset only, and
  computing the true metric against all N is the cost we're trying to avoid. Far primitives have
  astronomically negative logits in both modes so dropping them is numerically free.

### `primitive_logits(field, points, knn)`
- **Does**: shared cull -> Mahalanobis -> logits path, returns (idx, params, d, logits)
- **Rationale**: factored out so `fit/lloyd.py` reads the exact cell geometry the renderer
  renders. Two implementations of the metric would drift apart silently.

### `render_points(field, points, mode, knn, tau, background, bg_cell)`
- **Does**: (M,3) points -> (M,3) RGB
- **Interacts with**: `PrimitiveField.gather`, called by `fit/fitter.fit_volume`
- **Rationale**: operates on a flat point list rather than a grid, so the same path serves both
  stochastic-voxel training and full-volume inference. Computes `y = S^-1 R^T d` and takes
  `|y|^2` rather than materializing (M,K,3,3) inverse covariances — same result, far less memory.
- `bg_cell` (voronoi only): (logit, color) background pseudo-cell — a seed at infinity with a
  flat logit competing in the softmax. Errors if passed in additive mode.

### `render_volume(field, grid, chunk)`
- **Does**: chunked full-grid render for inference/eval

## Decisions
- **One renderer, not two.** `mode` is a flag. Rejected separate SplatRenderer/VoronoiRenderer
  classes: they would have drifted apart and made the A/B meaningless.
- **tau anneal lives in the caller** (`fit/fitter._tau`), not here — the renderer stays stateless.
- Additive mode takes an optional learned constant background. **[revised 2026-07-31]** The
  original position — "voronoi doesn't need one, a partition of unity covers the volume by
  construction" — proved to be a handicap, not a feature, on real footage: voronoi had to
  spend cells tiling flat background that additive got nearly free. The optional `bg_cell`
  pseudo-cell is the partition-of-unity-compatible answer (off by default; part of the
  voronoi steelman round).
- Softmax is taken over the *culled* set, not all N. Formally an approximation; numerically
  irrelevant because excluded logits are ~-inf.

## Contracts

| Dependent | Expects | Breaking changes |
|-----------|---------|------------------|
| `fit/fitter.py` | `render_points(...) -> (M,3)`, differentiable wrt all field params | Signature, return shape |
| `experiments/*` | `mode` accepts "additive"/"voronoi" | Mode names |

## Notes
- Pure PyTorch, no tile rasterizer. This is the throughput bottleneck and the obvious first
  optimization once the representation question is settled.
- `tau` is ignored in additive mode.
