"""Renderer for spacetime primitive fields.

THE CENTRAL DESIGN CLAIM OF THIS REPO:

    additive splats and soft anisotropic Voronoi are the SAME model
    under different normalization of the per-primitive contribution.

Given Mahalanobis distance q_i(x) = (x-mu_i)^T Sigma_i^-1 (x-mu_i) and
logits l_i(x) = -q_i/2 + log w_i:

    additive:  value(x) = bg + sum_i exp(l_i) * c_i        (unnormalized)
    voronoi:   value(x) = sum_i softmax_i(l_i / tau) * c_i (partition of unity)

As tau -> 0 the Voronoi mode anneals to a hard anisotropic power-diagram cell
assignment. So one flag and one temperature schedule spans the whole family,
and a fair A/B is a change of argument rather than a change of codebase.
"""

from __future__ import annotations

import torch

from core.params import PrimitiveField


def cull_knn(points: torch.Tensor, mu: torch.Tensor, k: int) -> torch.Tensor:
    """Select the k nearest primitives (by Euclidean center distance).

    points (M, 3), mu (N, 3) -> (M, k) long.

    Euclidean rather than Mahalanobis on purpose: culling only needs a safe
    superset, and computing the full metric for all N would defeat the point.
    Far primitives have astronomically negative logits in both modes, so
    excluding them is numerically free.
    """
    k = min(k, mu.shape[0])
    d2 = torch.cdist(points, mu)
    return d2.topk(k, dim=1, largest=False).indices


def primitive_logits(
    field: PrimitiveField, points: torch.Tensor, *, knn: int
) -> tuple[torch.Tensor, dict, torch.Tensor, torch.Tensor]:
    """Shared cull -> Mahalanobis -> logits path: (idx, params, d, logits).

    Factored out so rendering and Lloyd relaxation (fit/lloyd.py) read the
    same cell geometry by construction — two implementations of the metric
    would let them drift apart silently.
    """
    idx = cull_knn(points, field.mu.detach(), knn)  # (M, K)
    p = field.gather(idx)

    d = points[:, None, :] - p["mu"]  # (M, K, 3)

    # y = S^-1 R^T d  ->  q = |y|^2. Avoids materializing (M,K,3,3) inverses.
    rt_d = torch.einsum("mkji,mkj->mki", p["rot"], d)
    y = rt_d / (p["scale"] + 1e-8)
    q = (y * y).sum(-1)  # (M, K) squared Mahalanobis

    logits = -0.5 * q + torch.nn.functional.logsigmoid(p["logit_w"])
    return idx, p, d, logits


def render_points(
    field: PrimitiveField,
    points: torch.Tensor,
    *,
    mode: str = "additive",
    knn: int = 64,
    tau: float = 1.0,
    background: torch.Tensor | None = None,
    bg_cell: tuple[torch.Tensor, torch.Tensor] | None = None,
) -> torch.Tensor:
    """Evaluate the field at arbitrary (M, 3) query points -> (M, 3) RGB.

    Works on a flat point list, not a grid, so the same path serves full-volume
    reconstruction and random-voxel stochastic training.

    `bg_cell` (voronoi only) is a (logit, color) pair for a background
    pseudo-cell — a seed at infinity with a flat logit that competes in the
    softmax. Wherever every real primitive scores below it, the point falls to
    the background instead of forcing the nearest cell to stretch. This is the
    partition-of-unity counterpart of additive mode's `background` residual.
    """
    if mode not in ("additive", "voronoi"):
        raise ValueError(f"unknown mode {mode!r}")
    if bg_cell is not None and mode != "voronoi":
        raise ValueError("bg_cell is a voronoi-mode concept")

    _, p, d, logits = primitive_logits(field, points, knn=knn)

    color = p["color"]
    if field.p1_color:
        # P1 element: linear color ramp within the primitive's support.
        color = color + torch.einsum("mkij,mkj->mki", p["color_grad"], d)

    if mode == "additive":
        w = logits.exp()
        out = (w[..., None] * color).sum(1)
        if background is not None:
            out = out + background
    else:
        if bg_cell is not None:
            bg_logit, bg_color = bg_cell
            m = points.shape[0]
            logits = torch.cat([logits, bg_logit.reshape(1, 1).expand(m, 1)], 1)
            color = torch.cat([color, bg_color.reshape(1, 1, 3).expand(m, 1, 3)], 1)
        w = torch.softmax(logits / max(tau, 1e-4), dim=1)
        out = (w[..., None] * color).sum(1)

    return out


def render_volume(
    field: PrimitiveField,
    grid: torch.Tensor,
    *,
    chunk: int = 65536,
    **kw,
) -> torch.Tensor:
    """Render a full (M, 3) coordinate grid in chunks. Inference helper."""
    outs = []
    for i in range(0, grid.shape[0], chunk):
        outs.append(render_points(field, grid[i : i + chunk], **kw))
    return torch.cat(outs, 0)
