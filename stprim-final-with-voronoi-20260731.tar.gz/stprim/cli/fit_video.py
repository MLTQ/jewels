"""Fit one clip with additive splats, soft Voronoi, or both (A/B).

    python cli/fit_video.py --video clip.mp4 --mode both --frames 32 --size 256
    python cli/fit_video.py --synthetic --mode both        # falsification test

Both modes share every hyperparameter, so an A/B here is a genuine comparison
of normalization schemes rather than of two independently-tuned codebases.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from data.video_io import load_video, synthetic_tube  # noqa: E402
from fit.fitter import FitConfig, fit_volume  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", type=str, default=None)
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--mode", choices=["additive", "voronoi", "both"],
                    default="both")
    ap.add_argument("--frames", type=int, default=32)
    ap.add_argument("--size", type=int, default=256, help="resize short side")
    ap.add_argument("--num-init", type=int, default=2000)
    ap.add_argument("--max-primitives", type=int, default=10000)
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--voxels", type=int, default=65536)
    ap.add_argument("--knn", type=int, default=64)
    ap.add_argument("--t-scale", type=float, default=1.0)
    ap.add_argument("--no-p1", action="store_true",
                    help="constant color per primitive (P0) instead of linear ramp")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--out", type=str, default="runs")
    args = ap.parse_args()

    if args.synthetic:
        vid = synthetic_tube(T=args.frames, H=args.size, W=args.size)
        name = "synthetic"
    elif args.video:
        vid = load_video(args.video, max_frames=args.frames, resize=args.size)
        name = Path(args.video).stem
    else:
        ap.error("pass --video PATH or --synthetic")

    print(f"volume: {tuple(vid.shape)}  ({vid.numel() // 3:,} voxels)")

    outdir = Path(args.out) / name
    outdir.mkdir(parents=True, exist_ok=True)

    modes = ["additive", "voronoi"] if args.mode == "both" else [args.mode]
    results = {}

    for mode in modes:
        print(f"\n=== {mode} ===")
        cfg = FitConfig(
            mode=mode,
            num_init=args.num_init,
            max_primitives=args.max_primitives,
            steps=args.steps,
            voxels_per_step=args.voxels,
            knn=args.knn,
            p1_color=not args.no_p1,
            t_scale=args.t_scale,
            seed=args.seed,
        )
        field, info = fit_volume(vid, cfg, device=args.device)
        results[mode] = info

        torch.save(
            {"state": field.state_dict(), "cfg": vars(cfg), "info": info},
            outdir / f"{mode}_seed{args.seed}.pt",
        )
        print(
            f"{mode}: final psnr~{info['history'][-1]['psnr']:.2f}  "
            f"N={info['n_final']}  {info['seconds']:.1f}s"
        )

    (outdir / "summary.json").write_text(json.dumps(results, indent=2))

    if len(modes) == 2:
        a = results["additive"]["history"][-1]["psnr"]
        v = results["voronoi"]["history"][-1]["psnr"]
        print(f"\nA/B  additive {a:.2f} dB   voronoi {v:.2f} dB   "
              f"delta {a - v:+.2f} dB")


if __name__ == "__main__":
    main()
