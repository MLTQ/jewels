"""Fit both modes on one clip and render side-by-side reconstructions.

    python cli/render_recon.py --synthetic --frames 24 --size 128   # eyeball A/B
    python cli/render_recon.py --video clip.mp4

Metrics answer "how well"; this answers "what does it actually look like" —
additive renders as soft Gaussian splats (the GSVC-style look), Voronoi at low
tau renders as hard crystalline cells. Writes to --out:

    compare.gif         [GT | additive | voronoi] per frame, looped
    contact_sheet.png   sampled frames x {GT, additive, add err, voronoi, vor err}
    {mode}_seed{s}.pt   checkpoint (state + cfg + info, background included)

Only needs PIL beyond the core requirements.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import Image  # noqa: E402

from core.volume import make_grid  # noqa: E402
from data.video_io import load_video, synthetic_tube  # noqa: E402
from fit.fitter import FitConfig, fit_volume  # noqa: E402
from models.render import render_volume  # noqa: E402


def reconstruct(field, info, cfg, *, device) -> torch.Tensor:
    """Full-volume render at end-of-training settings -> (T, H, W, 3) in [0,1]."""
    T, H, W = info["shape"]
    grid = make_grid((T, H, W), t_scale=cfg.t_scale, device=device)
    background = None
    if info["background"] is not None:
        background = torch.tensor(info["background"], device=device)
    bg_cell = None
    if info.get("bg_cell") is not None:
        bg_cell = (
            torch.tensor(info["bg_cell"]["logit"], device=device),
            torch.tensor(info["bg_cell"]["color"], device=device),
        )
    with torch.no_grad():
        out = render_volume(
            field,
            grid,
            mode=cfg.mode,
            knn=cfg.knn,
            # voronoi trains toward tau_end; rendering at any other tau shows a
            # model that was never fit
            tau=cfg.tau_end if cfg.mode == "voronoi" else 1.0,
            background=background,
            bg_cell=bg_cell,
        )
    return out.reshape(T, H, W, 3).clamp(0.0, 1.0)


def heat(err: torch.Tensor) -> torch.Tensor:
    """(...,) error in [0,1] -> (..., 3) black->red->yellow heatmap."""
    r = (3.0 * err).clamp(0, 1)
    g = (3.0 * err - 1.0).clamp(0, 1)
    b = (3.0 * err - 2.0).clamp(0, 1)
    return torch.stack([r, g, b], dim=-1)


def to_pil(frame: torch.Tensor, upscale: int) -> Image.Image:
    """(H, W, 3) float in [0,1] -> PIL image, nearest-upscaled."""
    arr = (frame.cpu().numpy() * 255).astype("uint8")
    img = Image.fromarray(arr)
    if upscale > 1:
        img = img.resize((img.width * upscale, img.height * upscale), Image.NEAREST)
    return img


def hstack(images: list[Image.Image], pad: int = 2) -> Image.Image:
    w = sum(i.width for i in images) + pad * (len(images) - 1)
    h = max(i.height for i in images)
    out = Image.new("RGB", (w, h), (255, 255, 255))
    x = 0
    for i in images:
        out.paste(i, (x, 0))
        x += i.width + pad
    return out


def vstack(images: list[Image.Image], pad: int = 2) -> Image.Image:
    w = max(i.width for i in images)
    h = sum(i.height for i in images) + pad * (len(images) - 1)
    out = Image.new("RGB", (w, h), (255, 255, 255))
    y = 0
    for i in images:
        out.paste(i, (0, y))
        y += i.height + pad
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", type=str, default=None)
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--frames", type=int, default=24)
    ap.add_argument("--size", type=int, default=128)
    ap.add_argument("--steps", type=int, default=2000)
    ap.add_argument("--num-init", type=int, default=1500)
    ap.add_argument("--max-primitives", type=int, default=6000)
    ap.add_argument("--voxels", type=int, default=65536)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--upscale", type=int, default=2)
    ap.add_argument("--out", type=str, default="recon_out")
    ap.add_argument("--steelman", action="store_true",
                    help="voronoi arm gets bg pseudo-cell + Lloyd; additive "
                         "arm unchanged")
    args = ap.parse_args()

    if args.synthetic:
        vid = synthetic_tube(T=args.frames, H=args.size, W=args.size)
    elif args.video:
        vid = load_video(args.video, max_frames=args.frames, resize=args.size)
    else:
        ap.error("pass --video PATH or --synthetic")

    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)
    gt = vid.to(device)
    T = gt.shape[0]

    recons: dict[str, torch.Tensor] = {}
    for mode in ("additive", "voronoi"):
        cfg = FitConfig(
            mode=mode, steps=args.steps, num_init=args.num_init,
            max_primitives=args.max_primitives, voxels_per_step=args.voxels,
            seed=args.seed,
        )
        if args.steelman and mode == "voronoi":
            cfg.bg_cell = True
            cfg.lloyd_every = 100
            cfg.lloyd_polish = 30
        field, info = fit_volume(gt, cfg, device=device, verbose=False)
        rec = reconstruct(field, info, cfg, device=device)
        recons[mode] = rec
        full_psnr = -10.0 * torch.log10(
            torch.nn.functional.mse_loss(rec, gt).clamp_min(1e-10)
        )
        print(f"{mode}: full-volume psnr {float(full_psnr):.2f} dB  "
              f"N={info['n_final']}  {info['seconds']:.0f}s", flush=True)
        torch.save(
            {"state": field.state_dict(), "cfg": vars(cfg), "info": info},
            outdir / f"{mode}_seed{args.seed}.pt",
        )

    up = args.upscale
    gif_frames = [
        hstack([to_pil(gt[t], up),
                to_pil(recons["additive"][t], up),
                to_pil(recons["voronoi"][t], up)])
        for t in range(T)
    ]
    gif_frames[0].save(
        outdir / "compare.gif", save_all=True, append_images=gif_frames[1:],
        duration=83, loop=0,
    )

    picks = sorted({0, T // 4, T // 2, 3 * T // 4, T - 1})
    rows = []
    for row in (
        [gt[t] for t in picks],
        [recons["additive"][t] for t in picks],
        [heat((recons["additive"][t] - gt[t]).abs().mean(-1) * 5) for t in picks],
        [recons["voronoi"][t] for t in picks],
        [heat((recons["voronoi"][t] - gt[t]).abs().mean(-1) * 5) for t in picks],
    ):
        rows.append(hstack([to_pil(f, up) for f in row]))
    vstack(rows).save(outdir / "contact_sheet.png")

    print(f"wrote {outdir}/compare.gif  (rows: GT | additive | voronoi)")
    print(f"wrote {outdir}/contact_sheet.png  "
          f"(rows: GT, additive, add err x5, voronoi, vor err x5; frames {picks})")


if __name__ == "__main__":
    main()
