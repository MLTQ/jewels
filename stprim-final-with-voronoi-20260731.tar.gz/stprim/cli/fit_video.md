# fit_video.py

## Purpose
Entry point. Fits one clip in one or both modes and writes checkpoints + a summary.

## Components

### `main()`
- **Does**: arg parsing, load/synthesize, run modes, save `.pt` per mode, print A/B delta
- **Interacts with**: `data/video_io.py`, `fit/fitter.py`

## Decisions
- `--mode both` shares every hyperparameter across the two runs. That's the point: a genuine
  comparison of normalization schemes, not of two independently-tuned setups.
- Saves full `state_dict` + cfg + info per run — these checkpoints ARE the stage-2 training data.

## Contracts

| Dependent | Expects | Breaking changes |
|-----------|---------|------------------|
| stage 2 (future) | `runs/<name>/<mode>_seed<k>.pt` with keys state/cfg/info | Checkpoint schema — freeze this before generating a corpus |

## Notes
- `--size` is the short side; aspect is preserved from the source (handled inside
  `load_video`). The old 16:9 assumption distorted anything else and is gone.
