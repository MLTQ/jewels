# render_recon.py

## Purpose
Visual counterpart to the metric scripts: fit both modes on one clip, render the full volume,
and emit human-viewable artifacts. Metrics say how well the fits converge; this shows what the
two representations actually look like — additive as soft Gaussian splats (the GSVC-family
look), Voronoi at annealed tau as hard crystalline cells.

## Components

### `reconstruct(field, info, cfg, device)`
- **Does**: full-volume render at end-of-training settings -> (T,H,W,3) clamped to [0,1]
- **Rationale**: voronoi renders at `cfg.tau_end`, not the `render_points` default tau=1.0 —
  the annealed model is the trained model; rendering soft shows something that was never fit.
  Additive re-adds `info["background"]` (see fitter.md — the background is not in the field's
  `state_dict`).

### `heat(err)` / `to_pil` / `hstack` / `vstack`
- **Does**: minimal black->red->yellow error map and PIL montage helpers
- **Rationale**: PIL-only on purpose; the training box has no matplotlib/torchvision/imageio
  (see data/video_io.md for the same dependency-tolerance stance).

## Outputs
- `compare.gif` — [GT | additive | voronoi] per frame, looped, nearest-upscaled
- `contact_sheet.png` — sampled frames x {GT, additive, add err x5, voronoi, vor err x5}
- `{mode}_seed{s}.pt` — checkpoints (state + cfg + info; info carries the background)

## Contracts

| Dependent | Expects | Breaking changes |
|-----------|---------|------------------|
| (none yet) | | |

Depends on `fit_volume` returning `info["background"]` and `info["shape"]`.

## Notes
- `--steelman` upgrades only the voronoi arm (bg pseudo-cell + Lloyd, see `fit/lloyd.md`);
  additive is untouched, `reconstruct` re-applies the pseudo-cell from `info["bg_cell"]`.
- Defaults mirror `experiments/canonicalization.py`'s real-budget defaults so the rendered fits
  are the same experiment, one seed.
- Reported PSNR here is true full-volume PSNR — comparable across runs, unlike the noisy
  sampled-batch PSNR in the fit loop (see fitter.md).
