# fitter.py

## Purpose
Per-clip stochastic-voxel fitting loop. This is stage 1 — the same stage GSVC/VeGaS occupy. It
exists to produce training data for the amortized/generative stage, so it's tuned for throughput
and reproducibility over last-dB quality.

## Components

### `FitConfig`
- **Does**: all hyperparameters, shared by both modes
- **Rationale**: one config type for both modes is what keeps the A/B fair

### `_tau(cfg, step)`
- **Does**: geometric anneal of Voronoi softmax temperature, soft blending -> hard cells
- **Rationale**: hard cell assignment from step 0 gives near-zero gradient to distant seeds;
  annealing lets seeds find their region first and sharpen after

### `fit_volume(video, cfg, device)`
- **Does**: (T,H,W,3) in [0,1] -> (PrimitiveField, info dict)
- **Interacts with**: `make_grid`, `sample_indices`, `render_points`, `adapt`

## Decisions
- Per-parameter-group learning rates: geometry (mu/scale/quat) at half the appearance LR.
  Geometry moving as fast as color destabilizes early fitting.
- **Voronoi steelman knobs (2026-07-31), all default-off** so earlier results stay reproducible:
  `bg_cell` (background pseudo-cell competing in the softmax; learned logit + color, carried in
  `info["bg_cell"]`), `lloyd_every`/`lloyd_rho` (interleaved damped soft-Lloyd, see `lloyd.md`),
  `lloyd_polish` + `polish_finetune` (full-strength Lloyd at `tau_end` after training, then an
  appearance-only refit — geometry stays frozen or the relaxation would be undone). No effect
  in additive mode.
- MSE only. Rejected adding SSIM/gradient loss for now — extra hyperparameters obscure the
  representation comparison, which is the actual question.
- PSNR reported is computed on the sampled voxel batch, so it's noisy and NOT comparable to
  published full-frame PSNR. It's a training signal, not a benchmark number.
- Optimizer rebuilt after every adapt (see `adapt.md`).

## Contracts

| Dependent | Expects | Breaking changes |
|-----------|---------|------------------|
| `cli/fit_video.py` | `(field, info)` with `info["history"]` entries carrying psnr/n | info schema |
| `experiments/canonicalization.py` | `FitConfig(seed=...)` fully determines the run | Seeding behaviour |

## Notes
- Background parameter only exists in additive mode. It is learned jointly but lives outside
  `PrimitiveField`, so `fit_volume` returns it in `info["background"]` (a 3-float list; None in
  voronoi mode). Anything reconstructing from a saved fit MUST add it back — `state_dict()`
  alone is not the full model in additive mode. It's a list, not a tensor, because `info` is
  JSON-serialized by `cli/fit_video.py`.
