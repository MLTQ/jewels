"""Soft Lloyd/CVT relaxation on primitive centers (voronoi mode's steelman).

The canonicalization docstring's argument for voronoi was that Lloyd
relaxation toward a centroidal tessellation is an actual canonicalization
*procedure* — a deterministic map whose fixed points don't depend on the init.
That mechanism was never implemented, so the mode has been scored without its
main claimed advantage. This module implements it:

    centroid_i = sum_x w_i(x) * x / sum_x w_i(x)      (soft cell centroid)
    mu_i      <- mu_i + rho * (centroid_i - mu_i)     (damped Lloyd step)

with w_i(x) the same softmax cell assignment the renderer uses (shared via
models.render.primitive_logits, so relaxation and rendering can never disagree
about cell geometry). Expectations are estimated on stochastic voxel samples,
consistent with the fitting loop's whole design.

With a background pseudo-cell active, background-region points assign their
mass to it rather than to real seeds, so centroids are computed over content —
the two steelman mechanisms are complementary, not independent.
"""

from __future__ import annotations

import torch

from core.params import PrimitiveField
from models.render import primitive_logits


@torch.no_grad()
def soft_lloyd_step(
    field: PrimitiveField,
    points: torch.Tensor,
    *,
    knn: int,
    tau: float,
    rho: float,
    bg_logit: torch.Tensor | None = None,
) -> float:
    """One damped soft-Lloyd step on (M, 3) sample points. Returns mean |move|.

    Mutates `field.mu` in place. Gradient state for mu goes slightly stale, the
    same trade the adapt step already makes (and pays for by optimizer rebuild;
    a Lloyd nudge is far smaller, so it doesn't warrant one).
    """
    idx, _, _, logits = primitive_logits(field, points, knn=knn)  # (M, K)

    if bg_logit is not None:
        m = points.shape[0]
        logits = torch.cat([logits, bg_logit.reshape(1, 1).expand(m, 1)], 1)

    w = torch.softmax(logits / max(tau, 1e-4), dim=1)
    if bg_logit is not None:
        w = w[:, :-1]  # background mass moves no seed

    n = len(field)
    flat_idx = idx.reshape(-1)
    mass = torch.zeros(n, device=field.device)
    mass.scatter_add_(0, flat_idx, w.reshape(-1))
    moment = torch.zeros(n, 3, device=field.device)
    moment.scatter_add_(
        0,
        flat_idx[:, None].expand(-1, 3),
        (w[..., None] * points[:, None, :]).reshape(-1, 3),
    )

    seen = mass > 1e-6  # unsampled/starved cells stay put
    centroid = moment[seen] / mass[seen, None]
    move = rho * (centroid - field.mu[seen])
    field.mu[seen] += move
    return float(move.norm(dim=-1).mean()) if bool(seen.any()) else 0.0
