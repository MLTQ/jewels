# lloyd.py

## Purpose
Soft Lloyd/CVT relaxation on primitive centers — the voronoi steelman. The canonicalization
docstring's whole argument for voronoi was that Lloyd relaxation is an actual canonicalization
*procedure* (a deterministic map, init-independent at its fixed points), which additive splats
lack. Until 2026-07-31 that mechanism was never implemented, so voronoi was scored without its
main claimed advantage. This module exists to test that claim properly before the mode is
kept or killed.

## Components

### `soft_lloyd_step(field, points, knn, tau, rho, bg_logit)`
- **Does**: one damped step of mu_i <- mu_i + rho * (soft-cell centroid - mu_i), estimated on a
  stochastic voxel sample; returns mean |move| for logging
- **Interacts with**: `models/render.primitive_logits` (shared cell geometry — relaxation and
  rendering cannot disagree by construction); called by `fit/fitter.fit_volume`
- **Rationale**: soft assignments (softmax at the current tau) rather than hard argmax, so the
  step is consistent with what the renderer is actually optimizing at that point in the anneal.
  With a background pseudo-cell, background-region mass goes to it and moves no seed —
  centroids are computed over content, so the two steelman mechanisms compose.

## Decisions
- Mutates `field.mu` under `no_grad`; Adam moments for mu go slightly stale. Same trade the
  adapt step makes — a damped Lloyd nudge is far smaller, so no optimizer rebuild.
- Cells with no sampled mass stay put rather than being reset — starved cells are the prune
  step's job, not Lloyd's.
- Usage pattern (see fitter.py): damped (`rho≈0.3`) every `lloyd_every` steps during training,
  then `lloyd_polish` full-strength (`rho=1`) iterations at `tau_end` after training, followed
  by an appearance-only refit since moving seeds invalidates fitted colors.

## Contracts

| Dependent | Expects | Breaking changes |
|-----------|---------|------------------|
| `fit/fitter.py` | in-place mu update, no optimizer invalidation | starting to replace Parameters |

## Notes
- Voronoi-mode concept only. Meaningless for additive splats (no cells to relax toward).
